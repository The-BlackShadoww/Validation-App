//! <<<<<<<<<< UI elements >>>>>>>>>>> 

let optionList = document.querySelector('#options');

let validationTitle = document.querySelector('#validationTitle')

let userInput = document.querySelector('#userInput');

let validationBox = document.querySelector('#validationBox');

let validationStatus = document.querySelector('#validationStatus');

let form = document.querySelector('#form');



//! <<<<<<<<<< Regular Expressions >>>>>>>>>>> 


//*  ------------- Regular Expression for E-mail validation ---------------

let emailRegEx =  /^([a-zA-Z0-9]\.?)+[^\.\!\@\#\$\%\^\&\_\~\`\*\/\+\-]@([a-zA-Z0-9]\.?)+[^\.\!\@\#\$\%\^\&\_\~\`\*\/\+\-]$/;

//*  ------------- Regular Expression for Phone Number validation ---------------

let phoneRegEx = /^(\+)?(88)?01[0-9]{9}$/;

//*  ------------- Regular Expression for Post Code validation ---------------

let postRegEx = /^\d{4}$/;

//*  ------------- Regular Expression for TIN Number  validation ---------------

let TinRgEx = /^\d{12}$/;



//! <<<<<<<<<< Eventlistener >>>>>>>>>>> 


optionList.addEventListener('click', optionSelect);

form.addEventListener('submit', validation);



//! <<<<<<<<<< Function >>>>>>>>>>> 


//todo ----------- Function for getting the option selected by the user  ---------------

function optionSelect(e) {

    
    if (e.target.tagName === 'LI') {
        
        let option = e.target.textContent; 

        validationTitle.innerHTML = `${option}`;

        validationBox.classList = 'validationBox card p-5';


    }

}


//todo ----------- Function for actual validation  ---------------


function validation (e) {

    e.preventDefault();

    let option = validationTitle.innerHTML;

    let input = userInput.value;

    switch(option){

        case 'E-mail':

            if(emailRegEx.test(input)){

                validationStatus.innerHTML = `*Valid Email`;

                validationStatus.style.color = '#55a630';

            }else{

                validationStatus.innerHTML = `*Invalid Email. Your email can not have any spacial character before @ and can not end with a spacial character.`;

                validationStatus.style.color = '#d00000';

            }
        
            break;

        case 'Phone Number':

            if(phoneRegEx.test(input)){

                validationStatus.innerHTML = `*Valid Phone Number`;

                validationStatus.style.color = '#55a630';

            }else{

                validationStatus.innerHTML = `*Invalid Phone Number. Your number must consist of 11 digits including 01 at the beginning.`;

                validationStatus.style.color = '#d00000';

            }

            break;

        case 'TIN Number':

            if(TinRgEx.test(input)){

                validationStatus.innerHTML = `*Valid TIN Number`;

                validationStatus.style.color = '#55a630';

            }else{

                validationStatus.innerHTML = `*Invalid TIN Number. TIN Number must have exactly 12 digits.`;

                validationStatus.style.color = '#d00000';

            }               

            break;

        case 'Post Code':

            if(postRegEx.test(input)){

                validationStatus.innerHTML = `*Valid  Post Code`;

                validationStatus.style.color = '#55a630';

            }else{

                validationStatus.innerHTML = `*Invalid  Post Code. Post code must have exactly 4 digits.`;

                validationStatus.style.color = '#d00000';

            }              

            break;

        default:

            validationStatus.innerHTML = `*Error`;

            validationStatus.style.color = '#d00000';

            break;
    }

    userInput.value = '';    
    
}






